export const SET_MOBILE = 'SET_MOBILE';
export const IS_LOGOUT = 'IS_LOGOUT';
export const PROGRESSING = 'PROGRESSING';
