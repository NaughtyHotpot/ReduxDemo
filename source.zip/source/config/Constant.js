export const VALIDATED = 'VALIDATED';
export const CANCEL = 'CANCEL';
