export const BASE_URL =
  'https://5de5e6459c4220001405b0c1.mockapi.io/dw/api/fe/';
